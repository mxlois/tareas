// ---------- TEMA CLARO / OSCURO ----------
const btnTema = document.getElementById("btnTema");

if (localStorage.getItem("tema") === "oscuro") {
    document.body.classList.add("oscuro");
}

btnTema.addEventListener("click", () => {
    document.body.classList.toggle("oscuro");
    const oscuro = document.body.classList.contains("oscuro");
    localStorage.setItem("tema", oscuro ? "oscuro" : "claro");
});

// ---------- RELOJ ----------
const hora = document.getElementById("hora");
const fecha = document.getElementById("fecha");

function actualizarReloj() {
    const ahora = new Date();
    hora.textContent = ahora.toLocaleTimeString("es-EC");
    fecha.textContent = ahora.toLocaleDateString("es-EC", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric"
    });
}
actualizarReloj();
setInterval(actualizarReloj, 1000);

// ---------- CONTADOR ----------
const numero = document.getElementById("numero");
let cuenta = 0;

document.getElementById("sumar").addEventListener("click", () => {
    cuenta++;
    numero.textContent = cuenta;
});

document.getElementById("restar").addEventListener("click", () => {
    cuenta--;
    numero.textContent = cuenta;
});

document.getElementById("reiniciar").addEventListener("click", () => {
    cuenta = 0;
    numero.textContent = cuenta;
});

// ---------- TAREAS ----------
const formTarea = document.getElementById("formTarea");
const inputTarea = document.getElementById("nuevaTarea");
const listaTareas = document.getElementById("listaTareas");

let tareas = JSON.parse(localStorage.getItem("tareas")) || [];

function guardar() {
    localStorage.setItem("tareas", JSON.stringify(tareas));
}

function dibujarTareas() {
    listaTareas.innerHTML = "";

    if (tareas.length === 0) {
        listaTareas.innerHTML = "<li>No tienes tareas. ¡Agrega una!</li>";
        return;
    }

    tareas.forEach((tarea, i) => {
        const li = document.createElement("li");
        if (tarea.hecha) li.classList.add("hecha");

        const texto = document.createElement("span");
        texto.textContent = tarea.texto;
        texto.addEventListener("click", () => {
            tareas[i].hecha = !tareas[i].hecha;
            guardar();
            dibujarTareas();
        });

        const borrar = document.createElement("button");
        borrar.textContent = "✕";
        borrar.addEventListener("click", () => {
            tareas.splice(i, 1);
            guardar();
            dibujarTareas();
        });

        li.append(texto, borrar);
        listaTareas.appendChild(li);
    });
}

formTarea.addEventListener("submit", (e) => {
    e.preventDefault();
    const texto = inputTarea.value.trim();
    if (texto === "") return;

    tareas.push({ texto: texto, hecha: false });
    guardar();
    dibujarTareas();
    inputTarea.value = "";
});

dibujarTareas();